package com.example.todoapp_pem

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class TaskAdapter(
    private var tasks: List<TodoTask>,
    private val onTaskClick: (TodoTask) -> Unit,
    private val onTaskLongClick: (TodoTask) -> Unit  // Добавляем обработку долгого нажатия
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivStatus: ImageView = itemView.findViewById(R.id.ivStatus)
        val tvTitle: TextView = itemView.findViewById(R.id.tvTaskTitle)
        val tvDesc: TextView = itemView.findViewById(R.id.tvTaskDesc)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.task_item, parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = tasks[position]
        holder.tvTitle.text = task.title
        holder.tvDesc.text = task.desc

        // Установка круглой иконки статуса
        if (task.status == "Выполнено") {
            holder.ivStatus.setImageDrawable(
                ContextCompat.getDrawable(holder.itemView.context, R.drawable.circle_checked)
            )
            holder.tvTitle.alpha = 0.6f
            holder.tvDesc.alpha = 0.6f
        } else {
            holder.ivStatus.setImageDrawable(
                ContextCompat.getDrawable(holder.itemView.context, R.drawable.circle_unchecked)
            )
            holder.tvTitle.alpha = 1.0f
            holder.tvDesc.alpha = 1.0f
        }

        // Короткое нажатие - изменение статуса
        holder.itemView.setOnClickListener {
            onTaskClick(task)
        }

        // Долгое нажатие - удаление задачи
        holder.itemView.setOnLongClickListener {
            onTaskLongClick(task)
            true
        }
    }

    override fun getItemCount(): Int = tasks.size

    fun updateTasks(newTasks: List<TodoTask>) {
        tasks = newTasks
        notifyDataSetChanged()
    }
}