package com.example.todoapp_pem

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY id DESC")
    fun getAllTasks(): Flow<List<TodoTask>>

    @Insert
    fun insert(task: TodoTask)

    @Update
    fun update(task: TodoTask)
    @Delete
    fun delete(task: TodoTask)
}