package com.example.todoapp_pem

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.Flow
import java.util.concurrent.Executors

class TaskViewModel(application: Application) : AndroidViewModel(application) {

    private val database = TaskDatabase.getDatabase(application)
    private val taskDao = database.taskDao()
    private val executor = Executors.newSingleThreadExecutor()

    val allTasks: Flow<List<TodoTask>> = taskDao.getAllTasks()

    fun addTask(title: String, desc: String = "") {
        executor.execute {
            val newTask = TodoTask(
                title = title,
                desc = desc,
                status = "Не выполнено"
            )
            taskDao.insert(newTask)
        }
    }

    fun updateTaskCompletion(task: TodoTask, isCompleted: Boolean) {
        executor.execute {
            val updatedTask = task.copy(
                status = if (isCompleted) "Выполнено" else "Не выполнено"
            )
            taskDao.update(updatedTask)
        }
    }

    fun deleteTask(task: TodoTask) {
        executor.execute {
            taskDao.delete(task)
        }
    }
}