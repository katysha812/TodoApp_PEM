package com.example.todoapp_pem

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: TaskAdapter
    private lateinit var tvTotalTasks: TextView
    private lateinit var tvCompletedTasks: TextView
    private lateinit var tvProgressPercent: TextView

    private lateinit var taskViewModel: TaskViewModel
    private var allTasks = listOf<TodoTask>()
    private var currentFilter = "Все"

    private lateinit var filterAll: TextView
    private lateinit var filterActive: TextView
    private lateinit var filterCompleted: TextView

    companion object {
        private const val REQUEST_ADD_TASK = 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Инициализация ViewModel
        taskViewModel = TaskViewModel(application)

        // ⭐ ДОБАВЛЯЕМ ТЕСТОВЫЕ ДАННЫЕ ПРИ ЗАПУСКЕ ⭐
        taskViewModel.addTestData()

        // Инициализация View
        val tvDate: TextView = findViewById(R.id.tvDate)
        recyclerView = findViewById(R.id.recyclerView)
        tvTotalTasks = findViewById(R.id.tvTotalTasks)
        tvCompletedTasks = findViewById(R.id.tvCompletedTasks)
        tvProgressPercent = findViewById(R.id.tvProgressPercent)
        val fab: FloatingActionButton = findViewById(R.id.fab)

        filterAll = findViewById(R.id.filterAll)
        filterActive = findViewById(R.id.filterActive)
        filterCompleted = findViewById(R.id.filterCompleted)

        setCurrentDate(tvDate)

        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = TaskAdapter(
            tasks = listOf(),
            onTaskClick = { task ->
                val isCompleted = task.status != "Выполнено"
                taskViewModel.updateTaskCompletion(task, isCompleted)
            },
            onTaskLongClick = { task ->
                showDeleteConfirmationDialog(task)
            }
        )
        recyclerView.adapter = adapter

        fab.setOnClickListener {
            val intent = Intent(this, AddTaskActivity::class.java)
            startActivityForResult(intent, REQUEST_ADD_TASK)
        }

        setupFilters()

        // Наблюдение за изменениями
        lifecycleScope.launch {
            taskViewModel.allTasks.collectLatest { tasks ->
                allTasks = tasks
                updateStatistics()
                applyFilter()
            }
        }
    }

    private fun setCurrentDate(tvDate: TextView) {
        val currentDate = Date()
        val dateFormat = SimpleDateFormat("E, dd MMMM, yyyy", Locale("ru"))
        val formattedDate = dateFormat.format(currentDate)
        val result = formattedDate.replaceFirstChar {
            if (it.isLowerCase()) it.titlecase(Locale("ru")) else it.toString()
        }
        tvDate.text = result
    }

    private fun setupFilters() {
        filterAll.setOnClickListener {
            currentFilter = "Все"
            updateFilterUI()
            applyFilter()
        }

        filterActive.setOnClickListener {
            currentFilter = "Активные"
            updateFilterUI()
            applyFilter()
        }

        filterCompleted.setOnClickListener {
            currentFilter = "Выполненные"
            updateFilterUI()
            applyFilter()
        }
    }

    private fun updateFilterUI() {
        filterAll.background = ContextCompat.getDrawable(this, R.drawable.filter_button)
        filterActive.background = ContextCompat.getDrawable(this, R.drawable.filter_button)
        filterCompleted.background = ContextCompat.getDrawable(this, R.drawable.filter_button)

        filterAll.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray))
        filterActive.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray))
        filterCompleted.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray))

        when (currentFilter) {
            "Все" -> {
                filterAll.background = ContextCompat.getDrawable(this, R.drawable.filter_button_selected)
                filterAll.setTextColor(Color.WHITE)
            }
            "Активные" -> {
                filterActive.background = ContextCompat.getDrawable(this, R.drawable.filter_button_selected)
                filterActive.setTextColor(Color.WHITE)
            }
            "Выполненные" -> {
                filterCompleted.background = ContextCompat.getDrawable(this, R.drawable.filter_button_selected)
                filterCompleted.setTextColor(Color.WHITE)
            }
        }
    }

    private fun applyFilter() {
        val filteredTasks = when (currentFilter) {
            "Активные" -> allTasks.filter { it.status == "Не выполнено" }
            "Выполненные" -> allTasks.filter { it.status == "Выполнено" }
            else -> allTasks
        }
        adapter.updateTasks(filteredTasks)
    }

    private fun updateStatistics() {
        val total = allTasks.size
        val completed = allTasks.count { it.status == "Выполнено" }
        val progress = if (total > 0) (completed * 100 / total) else 0

        tvTotalTasks.text = "Всего: $total"
        tvCompletedTasks.text = "Выполнено: $completed"
        tvProgressPercent.text = "($progress%)"
    }

    private fun showDeleteConfirmationDialog(task: TodoTask) {
        AlertDialog.Builder(this)
            .setTitle("Удаление задачи")
            .setMessage("Вы уверены, что хотите удалить задачу \"${task.title}\"?")
            .setPositiveButton("Удалить") { _, _ ->
                taskViewModel.deleteTask(task)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_ADD_TASK && resultCode == RESULT_OK) {
            val title = data?.getStringExtra("task_title") ?: ""
            val desc = data?.getStringExtra("task_desc") ?: ""
            if (title.isNotEmpty()) {
                taskViewModel.addTask(title, desc)
            }
        }
    }
}