package com.example.todoapp_pem

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class AddTaskActivity : AppCompatActivity() {

    private lateinit var etTitle: EditText
    private lateinit var etDesc: EditText
    private lateinit var btnSave: Button
    private lateinit var btnCancel: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_task)

        etTitle = findViewById(R.id.etTaskTitle)
        etDesc = findViewById(R.id.etTaskDesc)
        btnSave = findViewById(R.id.btnSave)
        btnCancel = findViewById(R.id.btnCancel)

        // Настройка кнопки "Сохранить" - малиновый фон
        val saveButtonDrawable = GradientDrawable()
        saveButtonDrawable.shape = GradientDrawable.RECTANGLE
        saveButtonDrawable.cornerRadius = 24f
        saveButtonDrawable.setColor(Color.parseColor("#FFFF4081"))
        btnSave.background = saveButtonDrawable
        btnSave.setTextColor(Color.WHITE)

        // Настройка кнопки "Отмена" - прозрачный фон с малиновой обводкой
        val cancelButtonDrawable = GradientDrawable()
        cancelButtonDrawable.shape = GradientDrawable.RECTANGLE
        cancelButtonDrawable.cornerRadius = 24f
        cancelButtonDrawable.setColor(Color.TRANSPARENT)
        cancelButtonDrawable.setStroke(2, Color.parseColor("#FFFF4081"))
        btnCancel.background = cancelButtonDrawable
        btnCancel.setTextColor(Color.parseColor("#FFFF4081"))

        btnSave.setOnClickListener {
            val title = etTitle.text.toString()
            val desc = etDesc.text.toString()

            val resultIntent = Intent()
            resultIntent.putExtra("title", title)
            resultIntent.putExtra("desc", desc)
            setResult(RESULT_OK, resultIntent)
            finish()
        }

        btnCancel.setOnClickListener {
            setResult(RESULT_CANCELED)
            finish()
        }
    }
}