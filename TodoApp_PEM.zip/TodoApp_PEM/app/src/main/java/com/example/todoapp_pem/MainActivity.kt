package com.example.todoapp_pem

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: TaskAdapter
    private lateinit var tvTotalTasks: TextView
    private lateinit var tvCompletedTasks: TextView
    private lateinit var tvProgressPercent: TextView

    private val allTasks = mutableListOf<TodoTask>()
    private var currentFilter = "Все" // "Все", "Активные", "Выполненные"
    private var currentTaskList = mutableListOf<TodoTask>()

    // Ссылки на кнопки фильтров
    private lateinit var filterAll: TextView
    private lateinit var filterActive: TextView
    private lateinit var filterCompleted: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Инициализация View
        val tvDate: TextView = findViewById(R.id.tvDate)
        recyclerView = findViewById(R.id.recyclerView)
        tvTotalTasks = findViewById(R.id.tvTotalTasks)
        tvCompletedTasks = findViewById(R.id.tvCompletedTasks)
        tvProgressPercent = findViewById(R.id.tvProgressPercent)
        val fab: FloatingActionButton = findViewById(R.id.fab)

        // Инициализация фильтров
        filterAll = findViewById(R.id.filterAll)
        filterActive = findViewById(R.id.filterActive)
        filterCompleted = findViewById(R.id.filterCompleted)

        // Установка текущей даты в формате "Пн, 23 Март, 2026г"
        setCurrentDate(tvDate)

        // Создание тестовых данных
        createTestData()

        // Настройка RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = TaskAdapter(currentTaskList) { clickedTask ->
            // Обработка нажатия на задачу (переключение статуса)
            val originalTask = allTasks.find { it.id == clickedTask.id }
            if (originalTask != null) {
                originalTask.status = if (originalTask.status == "Не выполнено") "Выполнено" else "Не выполнено"
                updateStatistics()
                applyFilter() // Обновляем список с учетом фильтра
            }
        }
        recyclerView.adapter = adapter

        // Настройка FAB
        fab.setOnClickListener {
            val intent = Intent(this, AddTaskActivity::class.java)
            startActivityForResult(intent, REQUEST_ADD_TASK)
        }

        // Настройка фильтров
        setupFilters()

        // Обновление статистики
        updateStatistics()

        // Применяем начальный фильтр
        applyFilter()
    }

    private fun setCurrentDate(tvDate: TextView) {
        val currentDate = Date()
        val dateFormat = SimpleDateFormat("E, dd MMMM, yyyy", Locale("ru"))
        val formattedDate = dateFormat.format(currentDate)
        // Делаем первую букву заглавной
        val result = formattedDate.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale("ru")) else it.toString() }
        tvDate.text = result
    }

    private fun setupFilters() {
        filterAll.setOnClickListener {
            currentFilter = "Все"
            updateFilterUI()
            applyFilter()
        }

        filterActive.setOnClickListener {
            currentFilter = "Активные"
            updateFilterUI()
            applyFilter()
        }

        filterCompleted.setOnClickListener {
            currentFilter = "Выполненные"
            updateFilterUI()
            applyFilter()
        }
    }

    private fun updateFilterUI() {
        // Сброс всех фильтров
        filterAll.background = ContextCompat.getDrawable(this, R.drawable.filter_button)
        filterActive.background = ContextCompat.getDrawable(this, R.drawable.filter_button)
        filterCompleted.background = ContextCompat.getDrawable(this, R.drawable.filter_button)

        filterAll.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray))
        filterActive.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray))
        filterCompleted.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray))

        // Установка выбранного фильтра
        when (currentFilter) {
            "Все" -> {
                filterAll.background = ContextCompat.getDrawable(this, R.drawable.filter_button_selected)
                filterAll.setTextColor(Color.WHITE)
            }
            "Активные" -> {
                filterActive.background = ContextCompat.getDrawable(this, R.drawable.filter_button_selected)
                filterActive.setTextColor(Color.WHITE)
            }
            "Выполненные" -> {
                filterCompleted.background = ContextCompat.getDrawable(this, R.drawable.filter_button_selected)
                filterCompleted.setTextColor(Color.WHITE)
            }
        }
    }

    private fun applyFilter() {
        currentTaskList.clear()
        currentTaskList.addAll(
            when (currentFilter) {
                "Активные" -> allTasks.filter { it.status == "Не выполнено" }
                "Выполненные" -> allTasks.filter { it.status == "Выполнено" }
                else -> allTasks.toList() // "Все"
            }
        )
        adapter.notifyDataSetChanged()
    }

    private fun createTestData() {
        allTasks.add(TodoTask(1, "Купить продукты", "Молоко, хлеб, яйца", "Не выполнено"))
        allTasks.add(TodoTask(2, "Сделать домашнее задание", "Выполнить задание по Kotlin", "Не выполнено"))
        allTasks.add(TodoTask(3, "Позвонить маме", "Спросить о здоровье", "Выполнено"))
        allTasks.add(TodoTask(4, "Сходить в спортзал", "Тренировка в 18:00", "Не выполнено"))
        allTasks.add(TodoTask(5, "Почитать книгу", "Прочитать 50 страниц", "Выполнено"))
    }

    private fun updateStatistics() {
        val total = allTasks.size
        val completed = allTasks.count { it.status == "Выполнено" }
        val progress = if (total > 0) (completed * 100 / total) else 0

        tvTotalTasks.text = "Всего: $total"
        tvCompletedTasks.text = "Выполнено: $completed"
        tvProgressPercent.text = "($progress%)"
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_ADD_TASK && resultCode == RESULT_OK) {
            val title = data?.getStringExtra("title") ?: ""
            val desc = data?.getStringExtra("desc") ?: ""
            if (title.isNotEmpty()) {
                val newId = if (allTasks.isEmpty()) 1 else allTasks.maxOfOrNull { it.id }!! + 1
                allTasks.add(TodoTask(newId, title, desc, "Не выполнено"))
                updateStatistics()
                applyFilter() // Обновляем список с учетом фильтра
            }
        }
    }

    companion object {
        private const val REQUEST_ADD_TASK = 1
    }
}