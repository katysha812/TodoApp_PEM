package com.example.todoapp_pem

data class TodoTask(
    val id: Int,
    val title: String,
    val desc: String,
    var status: String // "Не выполнено" или "Выполнено"
)